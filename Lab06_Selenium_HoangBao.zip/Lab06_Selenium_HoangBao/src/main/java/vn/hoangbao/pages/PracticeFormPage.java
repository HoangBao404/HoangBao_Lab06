package vn.hoangbao.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class PracticeFormPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public PracticeFormPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(
            driver, Duration.ofSeconds(15)
        );
    }

    public void openPage() {
        driver.get(
            "https://demoqa.com/automation-practice-form"
        );
    }

    public void enterStudentInfo(
        String firstName,
        String lastName,
        String email,
        String phone
    ) {
        wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.id("firstName")
            )
        ).sendKeys(firstName);

        driver.findElement(
            By.id("lastName")
        ).sendKeys(lastName);

        driver.findElement(
            By.id("userEmail")
        ).sendKeys(email);

        driver.findElement(
            By.id("userNumber")
        ).sendKeys(phone);
    }

    public void selectGenderMale() {
        driver.findElement(
            By.cssSelector("label[for='gender-radio-1']")
        ).click();
    }

    public void selectBirthDate(
        String year,
        String month,
        String day
    ) {
        driver.findElement(
            By.id("dateOfBirthInput")
        ).click();

        new Select(
            driver.findElement(
                By.className("react-datepicker__year-select")
            )
        ).selectByVisibleText(year);

        new Select(
            driver.findElement(
                By.className("react-datepicker__month-select")
            )
        ).selectByVisibleText(month);

        String dayNumber = String.format(
            "%03d", Integer.parseInt(day)
        );

        driver.findElement(
            By.cssSelector(
                ".react-datepicker__day--" + dayNumber
                + ":not(.react-datepicker__day--outside-month)"
            )
        ).click();
    }

    public void uploadFile(String filePath) {
        driver.findElement(
            By.id("uploadPicture")
        ).sendKeys(filePath);
    }

    public void submitForm() {
        WebElement submit = driver.findElement(
            By.id("submit")
        );

        ((JavascriptExecutor) driver).executeScript(
            "arguments[0].scrollIntoView({block:'center'});",
            submit
        );

        wait.until(
            ExpectedConditions.elementToBeClickable(
                By.id("submit")
            )
        ).click();
    }
 // ===== CHON MON HOC =====
    public void selectSubject(String subject) {

        WebElement input = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.id("subjectsInput")
            )
        );

        input.sendKeys(subject);

        // Cho danh sach goi y xuat hien
        wait.until(
            ExpectedConditions.elementToBeClickable(
                By.cssSelector(
                    ".subjects-auto-complete__option"
                )
            )
        ).click();

        System.out.println("Mon hoc: " + subject);
    }
 // ===== CHON SO THICH =====
    public void selectHobby(String hobby) {

        By hobbyLocator = By.xpath(
            "//label[normalize-space()='" + hobby + "']"
        );

        wait.until(
            ExpectedConditions.elementToBeClickable(
                hobbyLocator
            )
        ).click();

        System.out.println("So thich: " + hobby);
    }
 // ===== NHAP DIA CHI =====
    public void enterAddress(String address) {

        WebElement addressInput = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.id("currentAddress")
            )
        );

        addressInput.clear();
        addressInput.sendKeys(address);

        System.out.println("Dia chi: " + address);
    }
 // ===== DOC THONG TIN TRONG MODAL =====
    public String getConfirmationValue(String field) {

        By valueLocator = By.xpath(
            "//td[normalize-space()='" + field + "']" +
            "/following-sibling::td"
        );

        return wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                valueLocator
            )
        ).getText();
    }
    
    public String getConfirmationMessage() {
        return wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.id("example-modal-sizes-title-lg")
            )
        ).getText();
    }
}
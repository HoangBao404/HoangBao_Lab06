package vn.hoangbao.lab06;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.io.IOException;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.WebElement;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

public class OpenDemoQATest {

    @Test

public void testOpenDemoQA() throws IOException {


        WebDriver driver = new ChromeDriver();

        try {
            driver.manage().window().maximize();

            driver.get(
                "https://demoqa.com/automation-practice-form"
            );

            WebDriverWait wait = new WebDriverWait(
                driver, Duration.ofSeconds(15)
            );

            // Kiem tra URL va tieu de
            String currentUrl = driver.getCurrentUrl();
            String title = driver.getTitle();

            assertEquals(
                "https://demoqa.com/automation-practice-form",
                currentUrl
            );

            assertFalse(title.isBlank());

            // Nhap ho
            wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                    By.id("firstName")
                )
            ).sendKeys("Hoang");

            // Nhap ten
            driver.findElement(
                By.id("lastName")
            ).sendKeys("Bao");

            // Nhap email
            driver.findElement(
                By.id("userEmail")
            ).sendKeys("hoangbao@example.com");

            // Nhap so dien thoai
            driver.findElement(
                By.id("userNumber")
            ).sendKeys("0912345678");

            // In thong tin ra Console
            System.out.println("===== THONG TIN SINH VIEN =====");
            System.out.println("Ho: Hoang");
            System.out.println("Ten: Bao");
            System.out.println("Email: hoangbao@example.com");
            System.out.println("SDT: 0912345678");

            // Kiem tra gia tri da nhap
            assertEquals("Hoang",
                driver.findElement(By.id("firstName"))
                      .getAttribute("value"));

            assertEquals("Bao",
                driver.findElement(By.id("lastName"))
                      .getAttribute("value"));

            System.out.println("TEST PASSED - Nhap thong tin thanh cong!");
         // ===== CHON GIOI TINH =====
            wait.until(
                ExpectedConditions.elementToBeClickable(
                    By.cssSelector("label[for='gender-radio-1']")
                )
            ).click();

            System.out.println("Gioi tinh: Male");

            // ===== CHON NGAY SINH =====
            wait.until(
                ExpectedConditions.elementToBeClickable(
                    By.id("dateOfBirthInput")
                )
            ).click();

            // Chon nam sinh
            Select year = new Select(
                wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                        By.className("react-datepicker__year-select")
                    )
                )
            );
            year.selectByVisibleText("2003");

            // Chon thang sinh
            Select month = new Select(
                driver.findElement(
                    By.className("react-datepicker__month-select")
                )
            );
            month.selectByVisibleText("May");

            // Chon ngay 15
            wait.until(
                ExpectedConditions.elementToBeClickable(
                    By.cssSelector(
                        ".react-datepicker__day--015:not(.react-datepicker__day--outside-month)"
                    )
                )
            ).click();

            // Kiem tra ngay sinh da chon
            String birthDate = driver.findElement(
                By.id("dateOfBirthInput")
            ).getAttribute("value");

            System.out.println("Ngay sinh: " + birthDate);

            assertEquals("15 May 2003", birthDate);

            System.out.println("TEST PASSED - Chon ngay sinh thanh cong!");
         // ===== UPLOAD FILE =====

         // Lay duong dan file trong thu muc Documents
         // Tu dong tao file trong thu muc project
            Path filePath = Paths.get(
                "Lab06_HoangBao.txt"
            ).toAbsolutePath();

            // Tao noi dung file neu chua ton tai
            java.nio.file.Files.writeString(
                filePath,
                "LAB 06 - SELENIUM WEBDRIVER\n"
                + "Sinh vien: Hoang Bao\n"
                + "Noi dung: Kiem thu Upload File"
            );

            System.out.println("Da tao file: " + filePath);


         // Kiem tra file co ton tai
         assertTrue(
             java.nio.file.Files.isRegularFile(filePath),
             "Khong tim thay file: " + filePath
         );

         // Tim o Upload
         WebElement uploadInput = wait.until(
             ExpectedConditions.presenceOfElementLocated(
                 By.id("uploadPicture")
             )
         );

         // Gui duong dan file vao o Upload
         uploadInput.sendKeys(filePath.toString());

         // Lay ten file da chon
         String uploadedValue = uploadInput.getAttribute("value");

         // Kiem tra ten file
         assertNotNull(uploadedValue);
         assertTrue(
             uploadedValue.endsWith("Lab06_HoangBao.txt"),
             "Ten file upload khong dung!"
         );

         // In ket qua
         System.out.println("===== UPLOAD FILE =====");
         System.out.println("File: " + filePath.getFileName());
         System.out.println("Duong dan: " + filePath);
         System.out.println("TEST PASSED - Upload file thanh cong!");
      // ===== SUBMIT FORM =====

      // Cuon den nut Submit
      WebElement submitButton = driver.findElement(
          By.id("submit")
      );

      ((org.openqa.selenium.JavascriptExecutor) driver)
          .executeScript(
              "arguments[0].scrollIntoView({block:'center'});",
              submitButton
          );

      // Nhan Submit
      wait.until(
          ExpectedConditions.elementToBeClickable(
              By.id("submit")
          )
      ).click();

      // Cho thong bao xac nhan xuat hien
      WebElement modal = wait.until(
          ExpectedConditions.visibilityOfElementLocated(
              By.id("example-modal-sizes-title-lg")
          )
      );

      // Kiem tra tieu de thong bao
      String modalTitle = modal.getText();

      System.out.println("===== KET QUA SUBMIT =====");
      System.out.println("Thong bao: " + modalTitle);

      assertEquals(
          "Thanks for submitting the form",
          modalTitle
      );

      System.out.println("TEST PASSED - Submit thanh cong!");
        } finally {
            driver.quit();
        }
    }
}
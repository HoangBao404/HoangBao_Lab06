
package vn.hoangbao.lab06;

import java.time.Duration;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import vn.hoangbao.pages.PracticeFormPage;

import static org.junit.jupiter.api.Assertions.*;

public class PracticeFormDataTest {

    static Stream<Arguments> studentData() {
        return Stream.of(
            Arguments.of(
                "TC01", "Hoang", "Bao",
                "hoangbao@example.com",
                "0912345678", true
            ),
            Arguments.of(
                "TC02", "", "Bao",
                "hoangbao@example.com",
                "0912345678", false
            ),
            Arguments.of(
                "TC03", "Hoang", "Bao",
                "email-sai",
                "0912345678", false
            )
        );
    }

    @ParameterizedTest(name = "{0}")
    @MethodSource("studentData")
    void testStudentForm(
        String testCase,
        String firstName,
        String lastName,
        String email,
        String phone,
        boolean expectedSuccess
    ) {

        WebDriver driver = new ChromeDriver();

        try {
            driver.manage().window().maximize();

            PracticeFormPage page =
                new PracticeFormPage(driver);

            page.openPage();

            page.enterStudentInfo(
                firstName, lastName, email, phone
            );

            page.selectGenderMale();

            page.selectBirthDate(
                "2003", "May", "15"
            );

            page.submitForm();

         // ===== KIEM TRA KET QUA SUBMIT =====
            WebDriverWait wait = new WebDriverWait(
                driver, Duration.ofSeconds(10)
            );

            boolean modalVisible;

            if (expectedSuccess) {

                try {
                    wait.until(
                        org.openqa.selenium.support.ui.ExpectedConditions
                            .visibilityOfElementLocated(
                                By.id("example-modal-sizes-title-lg")
                            )
                    );

                    modalVisible = true;

                } catch (org.openqa.selenium.TimeoutException e) {

                    modalVisible = false;

                    // In cac truong chua hop le de kiem tra
                    Object invalidFields =
                        ((org.openqa.selenium.JavascriptExecutor) driver)
                            .executeScript(
                                "return Array.from(" +
                                "document.querySelectorAll('input:invalid')" +
                                ").map(e => e.id)"
                            );

                    System.out.println(
                        "TC01 - Cac truong khong hop le: "
                        + invalidFields
                    );
                }

            } else {

                modalVisible = driver.findElements(
                    By.id("example-modal-sizes-title-lg")
                ).stream().anyMatch(WebElement::isDisplayed);
            }


            if (expectedSuccess) {
                assertTrue(
                    modalVisible,
                    testCase + ": Submit phai thanh cong"
                );

                assertEquals(
                    "Thanks for submitting the form",
                    page.getConfirmationMessage()
                );
            } else {
                assertFalse(
                    modalVisible,
                    testCase + ": Form khong duoc Submit"
                );
            }

            System.out.println(
                testCase + " - TEST PASSED"
            );

        } finally {
            driver.quit();
        }
    }
}

package vn.hoangbao.lab06;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import vn.hoangbao.pages.PracticeFormPage;

import static org.junit.jupiter.api.Assertions.*;

public class PracticeFormTest {

    @Test
    public void testStudentRegistration() throws Exception {

        WebDriver driver = new ChromeDriver();

        try {
            driver.manage().window().maximize();

            PracticeFormPage page =
                new PracticeFormPage(driver);

            page.openPage();

            // Kiem tra URL va tieu de
            assertEquals(
                "https://demoqa.com/automation-practice-form",
                driver.getCurrentUrl()
            );
            assertFalse(driver.getTitle().isBlank());

            // Nhap thong tin sinh vien
            page.enterStudentInfo(
                "Hoang",
                "Bao",
                "hoangbao@example.com",
                "0912345678"
            );

            page.selectGenderMale();
            page.selectBirthDate("2003", "May", "15");

            // Tao file upload
            Path file = Paths.get(
                "Lab06_HoangBao.txt"
            ).toAbsolutePath();

            Files.writeString(
                file,
                "LAB 06 - SELENIUM WEBDRIVER"
            );

            page.uploadFile(file.toString());
         // Chon mon hoc
            page.selectSubject("Maths");

            // Chon so thich
            page.selectHobby("Sports");

            // Nhap dia chi
            page.enterAddress("Ho Chi Minh City");

            // Anh 1: Truoc Submit
            captureScreen(driver, "Before_Submit");

            // Gui form
            page.submitForm();

            // Cho modal va kiem tra
            String message = page.getConfirmationMessage();

            assertEquals(
                "Thanks for submitting the form",
                message
            );

            // Kiem tra thong tin xac nhan
         // ===== KIEM TRA THONG TIN SAU SUBMIT =====
            String studentName =
                page.getConfirmationValue("Student Name");

            String studentEmail =
                page.getConfirmationValue("Student Email");

            String gender =
                page.getConfirmationValue("Gender");

            String mobile =
                page.getConfirmationValue("Mobile");

            String subjects =
                page.getConfirmationValue("Subjects");

            String hobbies =
                page.getConfirmationValue("Hobbies");

            String picture =
                page.getConfirmationValue("Picture");

            String address =
                page.getConfirmationValue("Address");

            String dateOfBirth =
                page.getConfirmationValue("Date of Birth");

            // Kiem tra du lieu
            assertEquals("Hoang Bao", studentName);
            assertEquals("hoangbao@example.com", studentEmail);
            assertEquals("Male", gender);
            assertEquals("0912345678", mobile);
            assertEquals("Maths", subjects);
            assertEquals("Sports", hobbies);
            assertEquals("Lab06_HoangBao.txt", picture);
            assertEquals("Ho Chi Minh City", address);
            assertTrue(dateOfBirth.contains("2003"));

            System.out.println("===== XAC NHAN DANG KY =====");
            System.out.println("Ho ten: " + studentName);
            System.out.println("Email: " + studentEmail);
            System.out.println("Gioi tinh: " + gender);
            System.out.println("Dien thoai: " + mobile);
            System.out.println("Ngay sinh: " + dateOfBirth);
            System.out.println("Mon hoc: " + subjects);
            System.out.println("So thich: " + hobbies);
            System.out.println("File: " + picture);
            System.out.println("Dia chi: " + address);

            assertEquals("Hoang Bao", studentName);

            // Anh 2: Sau Submit
            captureScreen(driver, "After_Submit");

            System.out.println("===== KET QUA LAB 06 =====");
            System.out.println("Sinh vien: " + studentName);
            System.out.println("Thong bao: " + message);
            System.out.println("TEST PASSED");
            System.out.println("Da chup 2 anh man hinh!");

        } catch (Exception | AssertionError e) {
            captureScreen(driver, "Test_Error");
            throw e;
        } finally {
            driver.quit();
        }
    }

    public void captureScreen(
        WebDriver driver, String fileName
    ) throws Exception {

        Path folder = Paths.get("screenshots");
        Files.createDirectories(folder);

        File source = ((TakesScreenshot) driver)
            .getScreenshotAs(OutputType.FILE);

        Path destination = folder.resolve(
            fileName + ".png"
        );

        Files.copy(
            source.toPath(),
            destination,
            StandardCopyOption.REPLACE_EXISTING
        );

        System.out.println(
            "Da chup anh: " + destination
        );
    }
}